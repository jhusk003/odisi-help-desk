# ODiSI 7100 Help Desk

A chatbot that answers questions about the Luna ODiSI 7100 in plain language. It runs its AI inside each visitor's own web browser, so there is no subscription, no API key, no server and no monthly bill.

## What's in this folder

| File | What it is |
| --- | --- |
| `index.html` | The whole website: the chat page, the plain-English guide, and the full text of the ODiSI 7100 User's Guide (REV002). |
| `model-lib/…webgpu.wasm` | The small program (5 MB) that lets the AI model run on a visitor's graphics chip. |
| `README.md` | This guide. |

## Put it online for free (GitHub Pages, about 10 minutes)

1. Go to **github.com** and create a free account (or sign in).
2. Click the **+** at the top right, then **New repository**.
3. Name it `odisi-help-desk`, choose **Public**, and click **Create repository**.
4. On the next page, click the link **uploading an existing file**.
5. Unzip the download. Drag the **contents** of the `odisi-help-desk` folder (`index.html`, the `model-lib` folder and `README.md`) into the upload box, then click **Commit changes**.
6. Open the repository's **Settings**, then **Pages** in the left menu.
7. Under **Branch**, pick `main` and `/ (root)`, then click **Save**.
8. Wait one or two minutes and refresh. Your link appears at the top, for example `https://your-name.github.io/odisi-help-desk/`. Share that link with anyone.

GitHub's free plan needs the repository to be public, so anyone can see these files, including the manual text inside `index.html`. Make sure that's fine under Luna's terms for the manual.

**Alternative:** Cloudflare Pages (pages.cloudflare.com) is also free. Create a project, choose **Upload assets**, and drag in the same folder.

## How visitors use it

- The page works immediately on any device. Without AI, it shows the closest plain-English answer and the matching manual pages.
- On a computer with recent **Chrome or Edge** (newer Safari and Firefox versions may also work), visitors click **Turn on AI answers**. The AI model (about 0.9 GB) downloads once and is saved in their browser, so later visits start in seconds.
- The AI answers in everyday words, cites manual pages, and says so when the manual doesn't cover a question.
- Questions never leave the visitor's computer. Nothing is sent to any AI company.
- Phones and older or low-memory computers usually can't run the AI. They get the search answers instead.

## How long it will keep working

Nothing here needs you to log in, pay or renew. The site relies on four free services, each pinned to an exact version so nothing changes underneath it:

| Piece | Where it comes from | If it ever disappears |
| --- | --- | --- |
| The website | GitHub Pages (your account) | Upload the same folder to another free host. |
| The AI engine code (WebLLM 0.2.85) | jsDelivr, with unpkg and esm.run as backups | Save a copy into this site (below). |
| The AI model (Qwen2.5 1.5B Instruct) | Hugging Face, pinned to one exact version | Save a copy into this site (below). |
| Fonts | Google Fonts | The page falls back to standard system fonts. |

Free GitHub Pages sites have no expiry date and don't need updates to stay up. They stay online as long as the account and repository exist.

### Optional: make it fully self-contained

You only need this if one of the outside sources ever goes away.

- **Engine code:** download `https://cdn.jsdelivr.net/npm/@mlc-ai/web-llm@0.2.85/lib/index.js`, rename it `web-llm.js`, and put it in a folder named `vendor` in this site. The page uses that copy first.
- **AI model:** copy every file from `https://huggingface.co/mlc-ai/Qwen2.5-1.5B-Instruct-q4f16_1-MLC/tree/9bd564b064631febf14deadcac492efb761d60c3` into the folder `model/resolve/main/` in this site. The page uses that copy first. This adds about 0.9 GB, close to GitHub Pages' 1 GB site limit, so use Git or Cloudflare Pages rather than the web upload.

## Updating the content

All content lives in `index.html`: the manual text (the `manual` block) and the plain-English answers (the `kb` block). To use a newer manual revision, ask Claude to rebuild `index.html` from the new PDF, then upload the new file over the old one.

## Credits and licenses

- Manual text: *ODiSI 7100 User's Guide* REV002, © Luna Innovations Inc. 2024.
- AI engine: WebLLM by the MLC team, Apache License 2.0.
- AI model: Qwen2.5-1.5B-Instruct by the Qwen team (Alibaba Cloud), Apache License 2.0, converted by MLC.

This site is not made or endorsed by Luna Innovations. Answers can be wrong; check the cited manual page before changing settings, and contact Luna support (1-866-586-2682, solutions@lunainc.com) for anything safety-related.
